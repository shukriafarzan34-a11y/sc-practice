import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Use case: Manage Products (StaffUI > Product-Management Page). Add, update and remove products. */
public class ProductManagementPage extends JFrame {

    private final ProductManager manager;

    private final JTextField name = new JTextField(20);
    private final JComboBox<Object> category = new JComboBox<>();
    private final JTextField price = new JTextField(10);
    private final JCheckBox available = new JCheckBox("Available for sale", true);
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"Name", "Category", "Price", "Available"}, 0) {
        public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private String selectedName = null;   // name of the product loaded for editing

    public ProductManagementPage(ProductManager manager) {
        super("Product-Management Page");
        this.manager = manager;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        category.addItem("-- Select --");
        for (Category c : manager.getCategories()) category.addItem(c);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createTitledBorder("Product details"));
        FormUtil.addRow(form, 0, "Product name", true, name);
        FormUtil.addRow(form, 1, "Category", true, category);
        FormUtil.addRow(form, 2, "Price (Rs.)", true, price);
        FormUtil.addRow(form, 3, "Availability", false, available);

        JButton add = new JButton("Add");
        JButton update = new JButton("Update");
        JButton remove = new JButton("Remove");
        JButton clear = new JButton("Clear");
        add.addActionListener(e -> onAdd());
        update.addActionListener(e -> onUpdate());
        remove.addActionListener(e -> onRemove());
        clear.addActionListener(e -> clearFields());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(clear); buttons.add(remove); buttons.add(update); buttons.add(add);

        // Clicking a row loads it into the form so staff can edit or remove it.
        table.getSelectionModel().addListSelectionListener(e -> {
            int r = table.getSelectedRow();
            if (!e.getValueIsAdjusting() && r >= 0) {
                selectedName = model.getValueAt(r, 0).toString();
                name.setText(selectedName);
                for (int i = 1; i < category.getItemCount(); i++)
                    if (category.getItemAt(i).toString().equals(model.getValueAt(r, 1).toString())) category.setSelectedIndex(i);
                price.setText(model.getValueAt(r, 2).toString());
                available.setSelected("Yes".equals(model.getValueAt(r, 3)));
            }
        });

        JPanel north = new JPanel(new BorderLayout());
        north.add(form, BorderLayout.CENTER);
        north.add(buttons, BorderLayout.SOUTH);

        JLabel hint = new JLabel("* = required. Click a row to edit or remove it.");
        hint.setForeground(Color.GRAY);

        setLayout(new BorderLayout(6, 6));
        add(north, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(hint, BorderLayout.SOUTH);
        setSize(540, 520);
        setLocationRelativeTo(null);
        refreshTable();
    }

    private void refreshTable() {
        model.setRowCount(0);
        for (Product p : manager.getAllProducts())
            model.addRow(new Object[]{p.getName(), p.getCategory(), p.getPrice(), p.isAvailable() ? "Yes" : "No"});
    }

    /** Quick checks on the screen, then builds a Product from the fields. Returns null if something is wrong. */
    private Product readForm() {
        List<String> errors = new ArrayList<>();
        String n = name.getText().trim();
        if (n.length() < 2 || n.length() > 50) errors.add("Product name must be 2 to 50 characters.");
        if (category.getSelectedIndex() == 0) errors.add("Select a category.");
        if (!Validator.isPositiveNumber(price.getText())) errors.add("Price must be a number greater than 0.");
        if (!errors.isEmpty()) { FormUtil.showErrors(this, errors); return null; }
        return new Product(n, (Category) category.getSelectedItem(), Double.parseDouble(price.getText().trim()), available.isSelected());
    }

    private void show(ProductResult r) {
        if (r.isSuccess()) {
            JOptionPane.showMessageDialog(this, r.getMessage(), "Done", JOptionPane.INFORMATION_MESSAGE);
            refreshTable();
            clearFields();
        } else {
            FormUtil.showErrors(this, r.getErrors());
        }
    }

    private void onAdd() {
        Product p = readForm();
        if (p != null) show(manager.addProduct(p));
    }

    private void onUpdate() {
        if (selectedName == null) { JOptionPane.showMessageDialog(this, "Select a product from the table first.", "Nothing selected", JOptionPane.WARNING_MESSAGE); return; }
        Product p = readForm();
        if (p != null) show(manager.updateProduct(selectedName, p));
    }

    private void onRemove() {
        if (selectedName == null) { JOptionPane.showMessageDialog(this, "Select a product from the table first.", "Nothing selected", JOptionPane.WARNING_MESSAGE); return; }
        if (FormUtil.confirm(this, "Remove '" + selectedName + "'? This cannot be undone.")) show(manager.removeProduct(selectedName));
    }

    private void clearFields() {
        table.clearSelection();
        selectedName = null;
        name.setText(""); price.setText(""); category.setSelectedIndex(0); available.setSelected(true);
    }

    /** Demo start: wires the classes together. */
    public static void main(String[] args) {
        ProductRepository repo = new ProductRepository(new DBFacade());
        ProductManager manager = new ProductManager(new ProductValidator(repo), repo);
        SwingUtilities.invokeLater(() -> new ProductManagementPage(manager).setVisible(true));
    }
}


/** Product-Manager (Products package). Works as the controller: the screen talks only to this class. */
class ProductManager {
    private final ProductValidator validator;
    private final ProductRepository repository;
    private final Logger logger = Logger.getInstance();

    public ProductManager(ProductValidator validator, ProductRepository repository) {
        this.validator = validator; this.repository = repository;
    }

    public List<Product> getAllProducts() { return repository.findAll(); }
    public List<Category> getCategories() { return Category.all(); }

    public ProductResult addProduct(Product p) {
        List<String> errors = validator.validate(p, null);
        if (!errors.isEmpty()) { logger.log("Add product rejected: " + p.getName()); return ProductResult.failed(errors); }
        repository.save(p);
        logger.log("Product added: " + p.getName());
        return ProductResult.ok("Product '" + p.getName() + "' added successfully.");
    }

    public ProductResult updateProduct(String oldName, Product p) {
        List<String> errors = validator.validate(p, oldName);
        if (!errors.isEmpty()) { logger.log("Update product rejected: " + oldName); return ProductResult.failed(errors); }
        repository.update(oldName, p);
        logger.log("Product updated: " + oldName + " -> " + p.getName());
        return ProductResult.ok("Product '" + p.getName() + "' updated successfully.");
    }

    public ProductResult removeProduct(String name) {
        repository.remove(name);
        logger.log("Product removed: " + name);
        return ProductResult.ok("Product '" + name + "' removed.");
    }
}


/** Checks product data before it is saved. */
class ProductValidator {
    private final ProductRepository repository;
    public ProductValidator(ProductRepository repository) { this.repository = repository; }

    /** ignoreName is the product's own old name when updating, so it does not count as a duplicate. */
    public List<String> validate(Product p, String ignoreName) {
        List<String> errors = new ArrayList<>();
        String n = p.getName();
        if (n.length() < 2 || n.length() > 50) errors.add("Product name must be 2 to 50 characters.");
        if (p.getCategory() == null) errors.add("Select a category.");
        if (p.getPrice() <= 0 || p.getPrice() > 100000) errors.add("Price must be between 1 and 100000.");
        boolean sameAsOld = ignoreName != null && ignoreName.equalsIgnoreCase(n);
        if (!sameAsOld && repository.findByName(n) != null) errors.add("A product named '" + n + "' already exists.");
        return errors;
    }
}


/** What the manager sends back to the screen. */
class ProductResult {
    private final boolean success;
    private final String message;
    private final List<String> errors;
    private ProductResult(boolean success, String message, List<String> errors) {
        this.success = success; this.message = message; this.errors = errors;
    }
    public static ProductResult ok(String message) { return new ProductResult(true, message, new ArrayList<>()); }
    public static ProductResult failed(List<String> errors) { return new ProductResult(false, null, errors); }
    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public List<String> getErrors() { return errors; }
}


/** A bakery product. Each product belongs to one Category (association). */
class Product {
    private final String name;
    private final Category category;
    private final double price;
    private final boolean available;
    public Product(String name, Category category, double price, boolean available) {
        this.name = name; this.category = category; this.price = price; this.available = available;
    }
    public String getName() { return name; }
    public Category getCategory() { return category; }
    public double getPrice() { return price; }
    public boolean isAvailable() { return available; }
}


/** Product category (Cakes, Cookies, Bread, Snacks). */
class Category {
    private final String name;
    public Category(String name) { this.name = name; }
    public String getName() { return name; }
    @Override public String toString() { return name; }

    public static List<Category> all() {
        List<Category> list = new ArrayList<>();
        for (String n : new String[]{"Cakes", "Cookies", "Bread", "Snacks"}) list.add(new Category(n));
        return list;
    }
}


/** Parent class of all repositories (inheritance). It holds the link to the DBFacade. */
abstract class Repository {
    protected final DBFacade db;
    protected Repository(DBFacade db) { this.db = db; }
}


/** Persistence package: stores, updates and reads products through the DBFacade. */
class ProductRepository extends Repository {
    public ProductRepository(DBFacade db) { super(db); }

    public List<Product> findAll() { return db.selectProducts(); }
    public Product findByName(String name) {
        for (Product p : db.selectProducts()) if (p.getName().equalsIgnoreCase(name)) return p;
        return null;
    }
    public void save(Product p) { db.insertProduct(p); }
    public void update(String oldName, Product p) { db.updateProduct(oldName, p); }
    public void remove(String name) { db.deleteProduct(name); }
}


/** Facade: one simple door to the database. Here it is an in-memory demo database with sample products. */
class DBFacade {
    private final List<Product> products = new ArrayList<>();

    public DBFacade() {
        products.add(new Product("Chocolate Cake", new Category("Cakes"), 1800, true));
        products.add(new Product("Butter Cookies", new Category("Cookies"), 600, true));
        products.add(new Product("Brown Bread", new Category("Bread"), 220, true));
    }
    public List<Product> selectProducts() { return new ArrayList<>(products); }
    public void insertProduct(Product p) { products.add(p); }
    public void updateProduct(String oldName, Product p) {
        for (int i = 0; i < products.size(); i++)
            if (products.get(i).getName().equalsIgnoreCase(oldName)) { products.set(i, p); return; }
    }
    public void deleteProduct(String name) { products.removeIf(p -> p.getName().equalsIgnoreCase(name)); }
}


/** Singleton: only one Logger exists in the whole system (Logging package). */
class Logger {
    private static Logger instance;
    private Logger() { }
    public static Logger getInstance() {
        if (instance == null) instance = new Logger();
        return instance;
    }
    public void log(String message) { System.out.println("[LOG " + new java.util.Date() + "] " + message); }
}


/** Simple text and number checks used by the screen. */
class Validator {
    public static boolean isPositiveNumber(String s) {
        try { return Double.parseDouble(s.trim()) > 0; } catch (Exception e) { return false; }
    }
}


/** Small helper so every screen looks the same (consistent design). */
class FormUtil {
    public static void addRow(JPanel p, int row, String label, boolean required, JComponent field) {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 8, 5, 8);
        c.gridy = row;
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0;
        p.add(new JLabel("<html>" + label + (required ? " <font color='red'>*</font>" : "") + "</html>"), c);
        c.gridx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        p.add(field, c);
    }
    public static void showErrors(Component parent, List<String> errors) {
        StringBuilder sb = new StringBuilder("Please fix the following:\n\n");
        for (String e : errors) sb.append("- ").append(e).append("\n");
        JOptionPane.showMessageDialog(parent, sb.toString(), "Invalid input", JOptionPane.ERROR_MESSAGE);
    }
    public static boolean confirm(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent, message, "Please confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}
