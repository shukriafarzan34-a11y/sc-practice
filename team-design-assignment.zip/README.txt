Bakery Ordering System - Design assignment (screen, sequence diagram, patterns, refined classes)

IMPORTANT: the use cases below are ASSUMED. They were not written in the project documents.
  Sharif Ullah   -> Place Order
  Sayed Mehmood  -> Manage Products
If your group gave them different use cases, tell the person who prepared this so they can be changed.

Each folder has: one Java file (run it), a sequence diagram (png), a class diagram (png) and NOTES.txt.

How to run (needs the JDK):
  javac PlaceOrderPage.java      then   java PlaceOrderPage
  javac ProductManagementPage.java   then   java ProductManagementPage
(each file contains all its classes, so one file is enough)
