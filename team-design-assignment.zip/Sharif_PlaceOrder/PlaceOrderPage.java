import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/** Use case: Place Order (CustomerUI > Place-Order Form). The screen collects input; OrderController does the work. */
public class PlaceOrderPage extends JFrame {

    private final OrderController controller;
    private final List<OrderItem> items = new ArrayList<>();

    private final JTextField name = new JTextField(20);
    private final JTextField phone = new JTextField(20);
    private final JTextArea address = new JTextArea(3, 20);
    private final JComboBox<Object> product = new JComboBox<>();
    private final JSpinner qty = new JSpinner(new SpinnerNumberModel(1, 1, 50, 1));
    private final DefaultTableModel model = new DefaultTableModel(new String[]{"Product", "Qty", "Price", "Total"}, 0) {
        public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JLabel total = new JLabel("Total: Rs. 0");

    public PlaceOrderPage(OrderController controller) {
        super("Place-Order Form");
        this.controller = controller;
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        product.addItem("-- Select product --");
        for (Product p : controller.getAvailableProducts()) product.addItem(p);

        JPanel customer = new JPanel(new GridBagLayout());
        customer.setBorder(BorderFactory.createTitledBorder("Customer and delivery details"));
        FormUtil.addRow(customer, 0, "Full name", true, name);
        FormUtil.addRow(customer, 1, "Phone (11 digits)", true, phone);
        FormUtil.addRow(customer, 2, "Delivery address", true, new JScrollPane(address));

        JPanel itemPanel = new JPanel(new GridBagLayout());
        itemPanel.setBorder(BorderFactory.createTitledBorder("Order items"));
        FormUtil.addRow(itemPanel, 0, "Product", true, product);
        FormUtil.addRow(itemPanel, 1, "Quantity (1-50)", true, qty);
        JButton add = new JButton("Add to order");
        JButton remove = new JButton("Remove selected");
        add.addActionListener(e -> onAddItem());
        remove.addActionListener(e -> onRemoveItem());
        JPanel itemButtons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        itemButtons.add(add); itemButtons.add(remove);
        FormUtil.addRow(itemPanel, 2, "", false, itemButtons);

        JPanel top = new JPanel(new GridLayout(2, 1, 4, 4));
        top.add(customer); top.add(itemPanel);

        JButton place = new JButton("Place Order");
        JButton clear = new JButton("Clear");
        JButton cancel = new JButton("Cancel");
        place.addActionListener(e -> onPlaceOrder());
        clear.addActionListener(e -> clearAll());
        cancel.addActionListener(e -> dispose());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.add(total); buttons.add(cancel); buttons.add(clear); buttons.add(place);

        setLayout(new BorderLayout(6, 6));
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        setSize(580, 620);
        setLocationRelativeTo(null);
    }

    private void onAddItem() {
        if (product.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Please select a product first.", "Invalid input", JOptionPane.ERROR_MESSAGE);
            return;
        }
        OrderItem item = new OrderItem((Product) product.getSelectedItem(), (Integer) qty.getValue());
        items.add(item);
        model.addRow(new Object[]{item.getProduct().getName(), item.getQuantity(), (int) item.getProduct().getPrice(), (int) item.getTotal()});
        updateTotal();
    }

    private void onRemoveItem() {
        int r = table.getSelectedRow();
        if (r < 0) {
            JOptionPane.showMessageDialog(this, "Select a row to remove.", "Nothing selected", JOptionPane.WARNING_MESSAGE);
            return;
        }
        items.remove(r);
        model.removeRow(r);
        updateTotal();
    }

    private void updateTotal() {
        double sum = 0;
        for (OrderItem i : items) sum += i.getTotal();
        total.setText("Total: Rs. " + (int) sum);
    }

    private void onPlaceOrder() {
        // 1) quick checks on the screen (good input design: tell the user early)
        List<String> errors = new ArrayList<>();
        if (!Validator.isValidName(name.getText())) errors.add("Name: letters only, 2 to 50 characters.");
        if (!Validator.isValidPhone(phone.getText().trim())) errors.add("Phone must be exactly 11 digits (e.g. 03001234567).");
        if (address.getText().trim().length() < 10) errors.add("Delivery address must be at least 10 characters.");
        if (items.isEmpty()) errors.add("Add at least one product to the order.");
        if (!errors.isEmpty()) { FormUtil.showErrors(this, errors); return; }

        if (!FormUtil.confirm(this, "Place this order? " + total.getText())) return;

        // 2) the controller does the real work (business checks, save, log)
        Customer customer = new Customer(name.getText().trim(), phone.getText().trim(), address.getText().trim());
        OrderResult result = controller.placeOrder(customer, new ArrayList<>(items));

        if (result.isSuccess()) {
            JOptionPane.showMessageDialog(this, result.getMessage(), "Order confirmation", JOptionPane.INFORMATION_MESSAGE);
            clearAll();
        } else {
            FormUtil.showErrors(this, result.getErrors());
        }
    }

    private void clearAll() {
        name.setText(""); phone.setText(""); address.setText("");
        product.setSelectedIndex(0); qty.setValue(1);
        items.clear(); model.setRowCount(0); updateTotal();
    }

    /** Demo start: wires the classes together. */
    public static void main(String[] args) {
        DBFacade db = new DBFacade();
        ProductRepository products = new ProductRepository(db);
        OrderController controller = new OrderController(new OrderValidator(products), products, new OrderRepository(db));
        SwingUtilities.invokeLater(() -> new PlaceOrderPage(controller).setVisible(true));
    }
}


/** Controller pattern: the screen talks only to this class. It runs the whole Place Order use case. */
class OrderController {
    private final OrderValidator validator;
    private final ProductRepository productRepository;
    private final OrderRepository orderRepository;
    private final Logger logger = Logger.getInstance();

    public OrderController(OrderValidator validator, ProductRepository productRepository, OrderRepository orderRepository) {
        this.validator = validator; this.productRepository = productRepository; this.orderRepository = orderRepository;
    }

    public List<Product> getAvailableProducts() { return productRepository.findAvailable(); }

    public OrderResult placeOrder(Customer customer, List<OrderItem> items) {
        List<String> errors = validator.validate(customer, items);
        if (!errors.isEmpty()) {
            logger.log("Order rejected: " + errors.size() + " validation error(s)");
            return new OrderResult(false, null, errors);
        }
        Order order = new Order(orderRepository.nextOrderId(), customer);
        for (OrderItem i : items) order.addItem(i);
        orderRepository.save(order);
        logger.log("Order placed: " + order.getOrderId() + ", total " + (int) order.getTotal());
        return new OrderResult(true, "Order " + order.getOrderId() + " placed successfully. Total: Rs. "
                + (int) order.getTotal() + ". Next step: payment.", new ArrayList<>());
    }
}


/** Order-Validator (Application Tier): business checks before the order is saved. */
class OrderValidator {
    private final ProductRepository productRepository;
    public OrderValidator(ProductRepository productRepository) { this.productRepository = productRepository; }

    public List<String> validate(Customer c, List<OrderItem> items) {
        List<String> errors = new ArrayList<>();
        if (!Validator.isValidName(c.getName())) errors.add("Name: letters only, 2 to 50 characters.");
        if (!Validator.isValidPhone(c.getPhone())) errors.add("Phone must be exactly 11 digits.");
        if (c.getAddress().length() < 10) errors.add("Delivery address must be at least 10 characters.");
        if (items.isEmpty()) errors.add("The order has no products.");
        for (OrderItem i : items) {
            if (i.getQuantity() < 1 || i.getQuantity() > 50) errors.add(i.getProduct().getName() + ": quantity must be 1 to 50.");
            if (!productRepository.isAvailable(i.getProduct().getName()))
                errors.add(i.getProduct().getName() + " is no longer available. Please remove it.");
        }
        return errors;
    }
}


/** What the controller sends back to the screen. */
class OrderResult {
    private final boolean success;
    private final String message;
    private final List<String> errors;
    public OrderResult(boolean success, String message, List<String> errors) {
        this.success = success; this.message = message; this.errors = errors;
    }
    public boolean isSuccess() { return success; }
    public String getMessage() { return message; }
    public List<String> getErrors() { return errors; }
}


/** Customer details typed on the form. An Order is linked to one Customer (association). */
class Customer {
    private final String name, phone, address;
    public Customer(String name, String phone, String address) { this.name = name; this.phone = phone; this.address = address; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
}


/** A bakery product. */
class Product {
    private final String name, category;
    private final double price;
    private final boolean available;
    public Product(String name, String category, double price, boolean available) {
        this.name = name; this.category = category; this.price = price; this.available = available;
    }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public boolean isAvailable() { return available; }
    @Override public String toString() { return name + " (Rs. " + (int) price + ")"; }
}


/** One product inside an order, with its quantity. */
class OrderItem {
    private final Product product;
    private final int quantity;
    public OrderItem(Product product, int quantity) { this.product = product; this.quantity = quantity; }
    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public double getTotal() { return quantity * product.getPrice(); }
}


/** An order. It holds its items (aggregation) and belongs to one customer (association). */
class Order {
    private final String orderId;
    private final Customer customer;
    private final List<OrderItem> items = new ArrayList<>();
    private String status = "Pending Payment";

    public Order(String orderId, Customer customer) { this.orderId = orderId; this.customer = customer; }
    public void addItem(OrderItem item) { items.add(item); }
    public void removeItem(OrderItem item) { items.remove(item); }
    public double getTotal() {
        double sum = 0;
        for (OrderItem i : items) sum += i.getTotal();
        return sum;
    }
    public String getOrderId() { return orderId; }
    public Customer getCustomer() { return customer; }
    public String getStatus() { return status; }
}


/** Parent class of all repositories (inheritance). It holds the link to the DBFacade. */
abstract class Repository {
    protected final DBFacade db;
    protected Repository(DBFacade db) { this.db = db; }
}


/** Persistence package: stores and reads products. */
class ProductRepository extends Repository {
    public ProductRepository(DBFacade db) { super(db); }

    public List<Product> findAvailable() {
        List<Product> result = new ArrayList<>();
        for (Product p : db.selectProducts()) if (p.isAvailable()) result.add(p);
        return result;
    }
    public boolean isAvailable(String productName) {
        for (Product p : db.selectProducts()) if (p.getName().equals(productName)) return p.isAvailable();
        return false;
    }
}


/** Persistence package: stores and reads orders. */
class OrderRepository extends Repository {
    private int counter = 1000;
    public OrderRepository(DBFacade db) { super(db); }

    public String nextOrderId() { return "ORD-" + (++counter); }
    public void save(Order o) { db.insertOrder(o); }
    public List<Order> findAll() { return db.selectOrders(); }
}


/** Facade: one simple door to the database. Here it is an in-memory demo database with sample products. */
class DBFacade {
    private final List<Product> products = new ArrayList<>();
    private final List<Order> orders = new ArrayList<>();

    public DBFacade() {
        products.add(new Product("Chocolate Cake", "Cakes", 1800, true));
        products.add(new Product("Butter Cookies", "Cookies", 600, true));
        products.add(new Product("Brown Bread", "Bread", 220, true));
        products.add(new Product("Chicken Patty", "Snacks", 150, true));
        products.add(new Product("Cream Roll", "Snacks", 120, false));
    }
    public List<Product> selectProducts() { return products; }
    public void insertOrder(Order o) { orders.add(o); }
    public List<Order> selectOrders() { return orders; }
}


/** Singleton: only one Logger exists in the whole system (Logging package). */
class Logger {
    private static Logger instance;
    private Logger() { }
    public static Logger getInstance() {
        if (instance == null) instance = new Logger();
        return instance;
    }
    public void log(String message) { System.out.println("[LOG " + new java.util.Date() + "] " + message); }
}


/** Simple text checks used by the screen and the validator. */
class Validator {
    public static boolean isEmpty(String s) { return s == null || s.trim().isEmpty(); }
    public static boolean isValidName(String s) { return s != null && s.trim().matches("[A-Za-z ]{2,50}"); }
    public static boolean isDigits(String s, int n) { return s != null && s.matches("\\d{" + n + "}"); }
    public static boolean isValidPhone(String s) { return isDigits(s, 11); }
}


/** Small helper so every screen looks the same (consistent design). */
class FormUtil {
    public static void addRow(JPanel p, int row, String label, boolean required, JComponent field) {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 8, 5, 8);
        c.gridy = row;
        c.anchor = GridBagConstraints.WEST;
        c.gridx = 0;
        p.add(new JLabel("<html>" + label + (required ? " <font color='red'>*</font>" : "") + "</html>"), c);
        c.gridx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        p.add(field, c);
    }
    public static void showErrors(Component parent, List<String> errors) {
        StringBuilder sb = new StringBuilder("Please fix the following:\n\n");
        for (String e : errors) sb.append("- ").append(e).append("\n");
        JOptionPane.showMessageDialog(parent, sb.toString(), "Invalid input", JOptionPane.ERROR_MESSAGE);
    }
    public static boolean confirm(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent, message, "Please confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}
