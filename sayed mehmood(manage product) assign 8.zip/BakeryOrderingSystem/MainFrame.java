
import javax.swing.*; // Used to create GUI components
import java.awt.*;   // Used for layouts, fonts, and dimensions

// MainFrame is the main window of our application
public class MainFrame extends JFrame {

    // Constructor: runs automatically when a MainFrame object is created
    public MainFrame() {

        setTitle("Manage Products");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Top panel for displaying the title
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());
        topPanel.setPreferredSize(new Dimension(0, 100));

        JLabel titleLabel = new JLabel(
            "Manage Bakery Products",
            SwingConstants.CENTER
        );

        titleLabel.setFont(new Font("Arial", Font.BOLD, 25));
        topPanel.add(titleLabel, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);

        // Panel for entering product information
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(5, 2, 10, 10));

        JLabel idLabel = new JLabel("Product ID:");
        JTextField idField = new JTextField();

        JLabel nameLabel = new JLabel("Product Name:");
        JTextField nameField = new JTextField();

        JLabel priceLabel = new JLabel("Price:");
        JTextField priceField = new JTextField();

        JLabel quantityLabel = new JLabel("Quantity:");
        JTextField quantityField = new JTextField();

        JLabel statusLabel = new JLabel("Product Status:");
        String[] statusOptions = {"Available", "Unavailable"};
        JComboBox<String> statusBox = new JComboBox<>(statusOptions);

        formPanel.add(idLabel);
        formPanel.add(idField);

        formPanel.add(nameLabel);
        formPanel.add(nameField);

        formPanel.add(priceLabel);
        formPanel.add(priceField);

        formPanel.add(quantityLabel);
        formPanel.add(quantityField);

        formPanel.add(statusLabel);
        formPanel.add(statusBox);

        // Panel for Add, Update and Delete buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        JButton addButton = new JButton("Add Product");
        addButton.setPreferredSize(new Dimension(130, 35));
        buttonPanel.add(addButton);

        JButton updateButton = new JButton("Update Product");
        updateButton.setPreferredSize(new Dimension(140, 35));
        buttonPanel.add(updateButton);

        JButton deleteButton = new JButton("Delete Product");
        deleteButton.setPreferredSize(new Dimension(130, 35));
        buttonPanel.add(deleteButton);

        // Panel for form and buttons
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BorderLayout(10, 20));
        centerPanel.setBorder(
            BorderFactory.createEmptyBorder(20, 40, 20, 40)
        );

        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(buttonPanel, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // Table for displaying product information
        String[] columns = {
            "Product ID",
            "Product Name",
            "Price",
            "Quantity",
            "Status"
        };

        String[][] data = {};

        JTable productTable = new JTable(data, columns);
        JScrollPane scrollPane = new JScrollPane(productTable);
        scrollPane.setPreferredSize(new Dimension(0, 200));

        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.setBorder(
            BorderFactory.createTitledBorder("Product List")
        );

        tablePanel.add(scrollPane, BorderLayout.CENTER);

        add(tablePanel, BorderLayout.SOUTH);

        setVisible(true);
    }
}
